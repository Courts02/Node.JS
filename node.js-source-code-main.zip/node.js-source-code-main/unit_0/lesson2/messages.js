"use strict";

let messages = [
    "A change of environment can be a good thing!",
    "You will make it!",
    "Just run the code!"
];