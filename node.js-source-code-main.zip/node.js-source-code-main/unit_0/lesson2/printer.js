"use strict";

let x = "Universe";
console.log(`Hello ${x}`);
