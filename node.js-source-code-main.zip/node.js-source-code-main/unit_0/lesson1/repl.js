"use strict";

3 + 3;

3 / 0;

console.log("Hello Universe!");

let name = "Jada Mathele";

console.log(name);

class Goat {
    eat(foodType) {
        console.log(`I love eating ${foodType}`);
    }
}

let billy = new Goat();
billy.eat("tin cans");