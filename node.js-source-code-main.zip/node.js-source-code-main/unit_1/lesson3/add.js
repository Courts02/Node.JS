exports.addNum = (x, y) => {
    let answer = x + y;
    console.log(`${x} + ${y} = ${answer}`);
};