exports.messages = [
    "You are great!",
    "You can accomplish anything!",
    "Success is in your future!"
];
//exports makes this array available
//to other files
//npm install <dependancy> --save
//npm init -y